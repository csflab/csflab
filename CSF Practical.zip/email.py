import re

with open("input.txt", "r") as emails, open("op.txt", "w") as results:
    resultsList = []

    for line in emails:
        if "From - " in line:
            resultsList.append("\n\t*** EMAIL HEADER DETAILS ***\n")

        if "From: " in line:
            address = re.findall(r'From:\s*([\w.-]+@[\w.-]+)', line)
            if address:
                resultsList.append("\nFrom: ")
                resultsList.append(address[0])

        if "To: " in line and "Delivered-To:" not in line:
            addresses = re.findall(r'To:\s*([\w.-]+@[\w.-]+)', line)
            if addresses:
                resultsList.append("\nTo: ")
                resultsList.extend(addresses)

        if "Bcc: " in line:
            addresses = re.findall(r'Bcc:\s*([\w.-]+@[\w.-]+)', line)
            if addresses:
                resultsList.append("\nBcc: ")
                resultsList.extend(addresses)

        if "Date: " in line:
            date = re.findall(r'Date:\s*(\w{3}.*)', line)
            if date:
                resultsList.append("\nDate: ")
                resultsList.append(date[0])

        if "Subject: " in line:
            subject = re.findall(r'Subject:\s*([\w\s.-]+)', line)
            if subject:
                resultsList.append("\nSubject: ")
                resultsList.append(subject[0])

    for result in resultsList:
        results.write(result)

# Print the results list for checking purposes (can be removed in production)
print("\n".join(resultsList))

import cv2
import numpy as np

def match_fingerprints(image1, image2):
    fingerprint1 = cv2.imread(image1, 0)  
    fingerprint2 = cv2.imread(image2, 0)  
    orb = cv2.ORB_create()
    keypoints1, descriptors1 = orb.detectAndCompute(fingerprint1, None)
    keypoints2, descriptors2 = orb.detectAndCompute(fingerprint2, None)

    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = bf.match(descriptors1, descriptors2)
    matches = sorted(matches, key=lambda x: x.distance)

    match_img = cv2.drawMatches(fingerprint1, keypoints1, fingerprint2, keypoints2, matches[:10], None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

    cv2.imshow('Matched Fingerprint', match_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

image_path1 = 'fingerprint1.jpg'  
image_path2 = 'fingerprint2.jpg'  
match_fingerprints(image_path1, image_path2)
